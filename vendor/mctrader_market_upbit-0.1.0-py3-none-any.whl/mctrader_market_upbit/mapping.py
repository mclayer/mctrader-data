from __future__ import annotations

from mctrader_market.types import Symbol, Timeframe

SUPPORTED_QUOTES: frozenset[str] = frozenset({"KRW", "USDT"})

TIMEFRAME_TO_UPBIT_PATH: dict[Timeframe, str] = {
    Timeframe.M1: "minutes/1",
    Timeframe.M5: "minutes/5",
    Timeframe.M15: "minutes/15",
    Timeframe.H1: "minutes/60",
    Timeframe.H4: "minutes/240",
    Timeframe.D1: "days",
}


def symbol_to_market_code(symbol: Symbol) -> str:
    """Symbol(base="BTC", quote="KRW") → "KRW-BTC"."""
    return str(symbol)


def market_code_to_symbol(code: str) -> Symbol:
    """Upbit market_code "KRW-BTC" → Symbol(base="BTC", quote="KRW")."""
    try:
        return Symbol.from_string(code)
    except ValueError as exc:
        raise ValueError(f"invalid Upbit market_code: {code!r}") from exc
