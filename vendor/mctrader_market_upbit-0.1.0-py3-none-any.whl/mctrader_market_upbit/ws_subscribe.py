from __future__ import annotations

import uuid
from collections.abc import Iterable
from typing import Any, Literal

from mctrader_market.types import Symbol

from mctrader_market_upbit.mapping import symbol_to_market_code
from mctrader_market_upbit.ws_secret_guard import assert_payload_clean

Channel = Literal["trade", "orderbook", "ticker"]


def build_subscribe_message(
    *,
    symbol: Symbol,
    channels: Iterable[Channel],
) -> list[dict[str, Any]]:
    """[{"ticket": uuid}, {"type": "trade", "codes": ["KRW-BTC"]}, ...]"""
    market_code = symbol_to_market_code(symbol)
    msgs: list[dict[str, Any]] = [{"ticket": str(uuid.uuid4())}]
    for ch in channels:
        entry: dict[str, Any] = {"type": ch, "codes": [market_code]}
        assert_payload_clean([entry])
        msgs.append(entry)
    return msgs
