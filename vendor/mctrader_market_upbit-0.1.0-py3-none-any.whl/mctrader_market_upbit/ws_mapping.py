from __future__ import annotations

from datetime import datetime, timezone
from decimal import Decimal
from typing import Any

from mctrader_market_upbit.exceptions import SchemaMismatchError
from mctrader_market_upbit.mapping import market_code_to_symbol
from mctrader_market_upbit.ws_events import (
    UpbitOrderbookEvent,
    UpbitStreamEvent,
    UpbitTickerEvent,
    UpbitTradeEvent,
    _OrderbookLevel,
)

_KNOWN_TYPES = frozenset({"trade", "orderbook", "ticker"})


def normalize_message(raw: dict[str, Any], received_at: datetime) -> UpbitStreamEvent | None:
    """Normalize raw Upbit WebSocket message → typed event. Returns None for non-data messages."""
    msg_type = raw.get("type")
    if msg_type not in _KNOWN_TYPES:
        return None

    code = raw.get("code")
    if not code:
        return None

    try:
        symbol = market_code_to_symbol(code)
    except ValueError:
        return None

    if msg_type == "trade":
        return _parse_trade(raw, symbol, received_at)
    elif msg_type == "orderbook":
        return _parse_orderbook(raw, symbol, received_at)
    elif msg_type == "ticker":
        return _parse_ticker(raw, symbol, received_at)
    return None


def _parse_trade(raw: dict, symbol: Any, received_at: datetime) -> UpbitTradeEvent:
    try:
        event_time = datetime.fromtimestamp(raw["trade_timestamp"] / 1000, tz=timezone.utc)
        side = "buy" if raw["ask_bid"] == "BID" else "sell"
        return UpbitTradeEvent(
            symbol=symbol,
            event_time=event_time,
            received_at=received_at,
            price=Decimal(str(raw["trade_price"])),
            quantity=Decimal(str(raw["trade_volume"])),
            side=side,
            raw=raw,
        )
    except (KeyError, TypeError, ValueError) as exc:
        raise SchemaMismatchError(f"trade parse failed: {exc}") from exc


def _parse_orderbook(raw: dict, symbol: Any, received_at: datetime) -> UpbitOrderbookEvent:
    try:
        event_time = datetime.fromtimestamp(raw["timestamp"] / 1000, tz=timezone.utc)
        units = raw["orderbook_units"]
        bids = tuple(
            _OrderbookLevel(price=Decimal(str(u["bid_price"])), quantity=Decimal(str(u["bid_size"])))
            for u in units
        )
        asks = tuple(
            _OrderbookLevel(price=Decimal(str(u["ask_price"])), quantity=Decimal(str(u["ask_size"])))
            for u in units
        )
        return UpbitOrderbookEvent(
            symbol=symbol,
            event_time=event_time,
            received_at=received_at,
            bids=bids,
            asks=asks,
            raw=raw,
        )
    except (KeyError, TypeError, ValueError) as exc:
        raise SchemaMismatchError(f"orderbook parse failed: {exc}") from exc


def _parse_ticker(raw: dict, symbol: Any, received_at: datetime) -> UpbitTickerEvent:
    try:
        event_time = datetime.fromtimestamp(raw["trade_timestamp"] / 1000, tz=timezone.utc)
        return UpbitTickerEvent(
            symbol=symbol,
            event_time=event_time,
            received_at=received_at,
            open=Decimal(str(raw["opening_price"])),
            high=Decimal(str(raw["high_price"])),
            low=Decimal(str(raw["low_price"])),
            close=Decimal(str(raw["trade_price"])),
            volume=Decimal(str(raw["acc_trade_volume_24h"])),
            raw=raw,
        )
    except (KeyError, TypeError, ValueError) as exc:
        raise SchemaMismatchError(f"ticker parse failed: {exc}") from exc
