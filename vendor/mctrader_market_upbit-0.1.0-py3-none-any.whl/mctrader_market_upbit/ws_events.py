from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel

from mctrader_market.types import Decimal38_18, Symbol, UTCDateTime


class _OrderbookLevel(BaseModel, frozen=True):
    price: Decimal38_18
    quantity: Decimal38_18


class UpbitTradeEvent(BaseModel, frozen=True):
    """Upbit trade event. kind="transaction" matches collector.py WAL channel key."""

    kind: Literal["transaction"] = "transaction"
    symbol: Symbol
    event_time: UTCDateTime
    received_at: UTCDateTime
    price: Decimal38_18
    quantity: Decimal38_18
    side: Literal["buy", "sell"]
    raw: dict[str, Any]


class UpbitOrderbookEvent(BaseModel, frozen=True):
    """Upbit orderbook — always full snapshot (15 levels). kind="orderbook_snapshot"."""

    kind: Literal["orderbook_snapshot"] = "orderbook_snapshot"
    symbol: Symbol
    event_time: UTCDateTime
    received_at: UTCDateTime
    bids: tuple[_OrderbookLevel, ...]
    asks: tuple[_OrderbookLevel, ...]
    raw: dict[str, Any]


class UpbitTickerEvent(BaseModel, frozen=True):
    kind: Literal["ticker"] = "ticker"
    symbol: Symbol
    event_time: UTCDateTime
    received_at: UTCDateTime
    open: Decimal38_18
    high: Decimal38_18
    low: Decimal38_18
    close: Decimal38_18
    volume: Decimal38_18
    raw: dict[str, Any]


UpbitStreamEvent = UpbitTradeEvent | UpbitOrderbookEvent | UpbitTickerEvent
