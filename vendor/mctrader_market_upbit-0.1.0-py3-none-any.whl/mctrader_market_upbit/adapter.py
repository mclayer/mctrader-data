from __future__ import annotations

from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation

from mctrader_market.candle import CandleModel
from mctrader_market.types import Symbol, Timeframe

from mctrader_market_upbit.client import UpbitHttpClient
from mctrader_market_upbit.exceptions import InsufficientCoverageError, SchemaMismatchError
from mctrader_market_upbit.mapping import TIMEFRAME_TO_UPBIT_PATH, symbol_to_market_code


def _normalize_row(row: dict, *, symbol: Symbol, timeframe: Timeframe) -> CandleModel:
    try:
        ts = datetime.fromisoformat(row["candle_date_time_utc"]).replace(tzinfo=timezone.utc)
        return CandleModel(
            ts_utc=ts,
            exchange="upbit",
            symbol=symbol,
            timeframe=timeframe,
            open=Decimal(str(row["opening_price"])),
            high=Decimal(str(row["high_price"])),
            low=Decimal(str(row["low_price"])),
            close=Decimal(str(row["trade_price"])),
            volume=Decimal(str(row["candle_acc_trade_volume"])),
            value=Decimal(str(row["candle_acc_trade_price"])),
            quarantine_reason=None,
        )
    except (KeyError, TypeError, ValueError, InvalidOperation) as exc:
        raise SchemaMismatchError(f"row parse failed: {exc}") from exc


class UpbitCandleProvider:
    """Upbit public REST OHLCV provider — paginated GET /candles/{path}."""

    def __init__(self, client: UpbitHttpClient | None = None) -> None:
        self._client = client or UpbitHttpClient()

    def get_candles(
        self,
        symbol: Symbol,
        timeframe: Timeframe,
        start: datetime,
        end: datetime,
    ) -> list[CandleModel]:
        market = symbol_to_market_code(symbol)
        path = TIMEFRAME_TO_UPBIT_PATH[timeframe]

        all_candles: list[CandleModel] = []
        to_ts = end

        while True:
            to_str = to_ts.strftime("%Y-%m-%dT%H:%M:%S")
            batch_raw = self._client.get_candlestick(market, path, count=200, to=to_str)
            if not batch_raw:
                break
            batch = [_normalize_row(r, symbol=symbol, timeframe=timeframe) for r in batch_raw]
            batch.sort(key=lambda c: c.ts_utc)
            all_candles = batch + all_candles
            if batch[0].ts_utc <= start:
                break
            to_ts = batch[0].ts_utc

        filtered = [c for c in all_candles if start <= c.ts_utc < end]
        self._verify_coverage(filtered, start, end, timeframe)
        return filtered

    @staticmethod
    def _verify_coverage(
        candles: list[CandleModel],
        start: datetime,
        end: datetime,
        timeframe: Timeframe,
    ) -> None:
        if not candles:
            raise InsufficientCoverageError(f"empty result for [{start}, {end})")
        first_gap = candles[0].ts_utc - start
        if first_gap > timeframe.delta:
            raise InsufficientCoverageError(
                f"first candle {candles[0].ts_utc} too far from start={start} (gap={first_gap})"
            )
        last_gap = end - candles[-1].ts_utc
        if last_gap > timeframe.delta * 2:
            raise InsufficientCoverageError(
                f"last candle {candles[-1].ts_utc} too far from end={end} (gap={last_gap})"
            )
