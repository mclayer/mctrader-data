from __future__ import annotations

from typing import Any

from mctrader_market_upbit.exceptions import PublicOnlyViolationError

ALLOWED_WS_URL = "wss://api.upbit.com/websocket/v1"

_FORBIDDEN_HEADERS: frozenset[str] = frozenset({
    "authorization",
    "api-key",
    "x-access-token",
    "x-access-nonce",
    "x-access-signature",
})

_FORBIDDEN_PAYLOAD_KEYS: frozenset[str] = frozenset({
    "access_key",
    "secret_key",
    "nonce",
    "signature",
    "api_key",
})


def assert_url_allowed(url: str) -> None:
    if url != ALLOWED_WS_URL:
        raise PublicOnlyViolationError(
            f"WebSocket URL not in allowlist: {url!r} (allowed: {ALLOWED_WS_URL!r})"
        )


def assert_headers_clean(headers: dict[str, str]) -> None:
    forbidden = {k for k in headers if k.lower() in _FORBIDDEN_HEADERS}
    if forbidden:
        raise PublicOnlyViolationError(
            f"forbidden WS handshake header: {sorted(forbidden)}"
        )


def assert_payload_clean(payload: list[dict[str, Any]]) -> None:
    for item in payload:
        forbidden = {k for k in item if k.lower() in _FORBIDDEN_PAYLOAD_KEYS}
        if forbidden:
            raise PublicOnlyViolationError(
                f"forbidden subscribe payload key: {sorted(forbidden)}"
            )
