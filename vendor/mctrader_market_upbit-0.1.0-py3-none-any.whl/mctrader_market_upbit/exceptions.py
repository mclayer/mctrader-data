from __future__ import annotations


class UpbitApiError(Exception):
    """Base for Upbit HTTP API failures."""


class RateLimitedError(UpbitApiError):
    """HTTP 429 — caller decides retry strategy."""


class SchemaMismatchError(UpbitApiError):
    """JSON parse / field type / structure error."""


class InsufficientCoverageError(UpbitApiError):
    """Response window does not cover requested [start, end) interval."""


class PublicOnlyViolationError(UpbitApiError):
    """Forbidden header / non-public URL detected."""
