from __future__ import annotations

import time
from collections.abc import Callable
from typing import Any

import httpx

from mctrader_market_upbit.exceptions import RateLimitedError, SchemaMismatchError, UpbitApiError

UPBIT_BASE_URL = "https://api.upbit.com/v1"


class UpbitHttpClient:
    """Upbit public REST client with simple rate limiting (10 req/sec)."""

    def __init__(
        self,
        client: httpx.Client | None = None,
        rate_per_second: float = 10.0,
        timeout: float = 10.0,
        clock: Callable[[], float] = time.monotonic,
        sleep: Callable[[float], None] = time.sleep,
    ) -> None:
        self._client = client or httpx.Client()
        self._min_interval = 1.0 / rate_per_second
        self._last_call = 0.0
        self._timeout = timeout
        self._clock = clock
        self._sleep = sleep

    def _throttle(self) -> None:
        now = self._clock()
        elapsed = now - self._last_call
        if elapsed < self._min_interval:
            self._sleep(self._min_interval - elapsed)
        self._last_call = self._clock()

    def get_candlestick(
        self,
        market: str,
        path: str,
        count: int = 200,
        to: str | None = None,
    ) -> list[dict[str, Any]]:
        url = f"{UPBIT_BASE_URL}/candles/{path}"
        params: dict[str, Any] = {"market": market, "count": count}
        if to is not None:
            params["to"] = to

        self._throttle()
        try:
            resp = self._client.get(url, params=params, timeout=self._timeout)
        except httpx.RequestError as exc:
            raise UpbitApiError(0, f"request failed: {exc}") from exc

        if resp.status_code == 429:
            raise RateLimitedError("HTTP 429 — rate limited")
        if resp.status_code >= 500:
            raise UpbitApiError(resp.status_code, f"server error {resp.status_code}")
        if resp.status_code >= 400:
            raise UpbitApiError(resp.status_code, f"client error {resp.status_code}: {resp.text[:200]}")

        try:
            data = resp.json()
        except Exception as exc:
            raise SchemaMismatchError(f"JSON parse failed: {exc}") from exc

        if not isinstance(data, list):
            raise SchemaMismatchError(f"expected list, got {type(data).__name__}: {str(data)[:100]}")

        return data

    def close(self) -> None:
        self._client.close()

    def __enter__(self) -> "UpbitHttpClient":
        return self

    def __exit__(self, *exc: object) -> None:
        self.close()
