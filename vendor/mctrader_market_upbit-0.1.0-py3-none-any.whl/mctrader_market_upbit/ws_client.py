from __future__ import annotations

import asyncio
import json
import random
from collections.abc import AsyncIterator, Callable, Iterable
from datetime import datetime, timezone

import websockets

from mctrader_market.types import Symbol

from mctrader_market_upbit.ws_events import UpbitStreamEvent
from mctrader_market_upbit.ws_mapping import normalize_message
from mctrader_market_upbit.ws_subscribe import Channel, build_subscribe_message
from mctrader_market_upbit.ws_secret_guard import ALLOWED_WS_URL, assert_url_allowed


class UpbitWebSocketStream:
    """Upbit public WebSocket stream — implements MarketStream protocol.

    Auto-reconnects with exponential backoff. Stale detection: no message for
    stale_seconds triggers reconnect.
    """

    def __init__(
        self,
        *,
        symbol: Symbol,
        channels: Iterable[Channel] = ("trade", "orderbook", "ticker"),
        url: str = ALLOWED_WS_URL,
        stale_seconds: float = 90.0,
        backoff_initial_seconds: float = 1.0,
        backoff_max_seconds: float = 60.0,
        backoff_jitter: float = 0.2,
        random_provider: Callable[[], float] = random.random,
    ) -> None:
        assert_url_allowed(url)
        self._symbol = symbol
        self._channels = tuple(channels)
        self._url = url
        self._stale_seconds = stale_seconds
        self._backoff_initial = backoff_initial_seconds
        self._backoff_max = backoff_max_seconds
        self._backoff_jitter = backoff_jitter
        self._random = random_provider
        self._closed = False

    async def __aenter__(self) -> "UpbitWebSocketStream":
        return self

    async def __aexit__(self, exc_type: object, exc: object, tb: object) -> None:
        await self.close()

    async def close(self) -> None:
        self._closed = True

    async def messages(self) -> AsyncIterator[UpbitStreamEvent]:
        delay = self._backoff_initial
        while not self._closed:
            try:
                async with websockets.connect(self._url) as ws:
                    sub = build_subscribe_message(symbol=self._symbol, channels=self._channels)
                    await ws.send(json.dumps(sub))
                    delay = self._backoff_initial
                    while not self._closed:
                        try:
                            raw_bytes = await asyncio.wait_for(
                                ws.recv(), timeout=self._stale_seconds
                            )
                        except asyncio.TimeoutError:
                            break
                        raw = json.loads(raw_bytes)
                        received_at = datetime.now(tz=timezone.utc)
                        event = normalize_message(raw, received_at)
                        if event is not None:
                            yield event
            except asyncio.CancelledError:
                return
            except Exception:
                if self._closed:
                    return
                jitter = 1.0 + self._backoff_jitter * (2 * self._random() - 1)
                wait = min(delay * jitter, self._backoff_max)
                await asyncio.sleep(wait)
                delay = min(delay * 2, self._backoff_max)
