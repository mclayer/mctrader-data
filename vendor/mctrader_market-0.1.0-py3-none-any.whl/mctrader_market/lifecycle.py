"""Pure function transition matrix for the 8-state Order lifecycle (ADR-002)."""

from __future__ import annotations

from mctrader_market.order import OrderStatus

_TRANSITIONS: dict[OrderStatus, frozenset[OrderStatus]] = {
    OrderStatus.NEW: frozenset({OrderStatus.ACCEPTED, OrderStatus.REJECTED}),
    OrderStatus.ACCEPTED: frozenset(
        {
            OrderStatus.PARTIALLY_FILLED,
            OrderStatus.FILLED,
            OrderStatus.CANCEL_REQUESTED,
            OrderStatus.EXPIRED,
        }
    ),
    OrderStatus.PARTIALLY_FILLED: frozenset(
        {OrderStatus.FILLED, OrderStatus.CANCEL_REQUESTED, OrderStatus.EXPIRED}
    ),
    # Race: cancel request 직후 fill 가능
    OrderStatus.CANCEL_REQUESTED: frozenset({OrderStatus.CANCELED, OrderStatus.FILLED}),
    OrderStatus.FILLED: frozenset(),
    OrderStatus.CANCELED: frozenset(),
    OrderStatus.REJECTED: frozenset(),
    OrderStatus.EXPIRED: frozenset(),
}


def can_transition(from_: OrderStatus, to: OrderStatus) -> bool:
    """Return True if (from_, to) is a valid transition per the ADR-002 8-state matrix."""
    return to in _TRANSITIONS.get(from_, frozenset())


TERMINAL_STATES: frozenset[OrderStatus] = frozenset(
    s for s, allowed in _TRANSITIONS.items() if not allowed
)
