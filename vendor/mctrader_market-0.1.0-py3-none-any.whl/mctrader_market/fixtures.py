"""Importable canonical fixtures for downstream contract tests.

Exchange-neutral examples only — Bithumb / Upbit specific raw fixtures live in
the corresponding adapter repos.
"""

from __future__ import annotations

from datetime import datetime, timezone
from decimal import Decimal

from mctrader_market.candle import CandleModel
from mctrader_market.order import Order, OrderSide, OrderStatus, OrderType
from mctrader_market.orderbook import OrderBookLevel, OrderBookModel
from mctrader_market.types import OrderId, Symbol, Timeframe


_DEFAULT_OPEN = Decimal("100000000.00")
_DEFAULT_HIGH = Decimal("100500000.00")
_DEFAULT_LOW = Decimal("99500000.00")
_DEFAULT_CLOSE = Decimal("100200000.00")


def make_valid_candle(
    *,
    ts_utc: datetime | None = None,
    exchange: str = "bithumb",
    symbol: Symbol | None = None,
    timeframe: Timeframe = Timeframe.H1,
    open_: Decimal = _DEFAULT_OPEN,
    high: Decimal | None = None,
    low: Decimal | None = None,
    close: Decimal | None = None,
    volume: Decimal = Decimal("1.5"),
    value: Decimal | None = None,
) -> CandleModel:
    """Create a valid CandleModel for use in tests.

    When ``open_`` is overridden but ``high``/``low``/``close`` are not, they
    are scaled proportionally so that OHLCV invariants (ADR-018 D3) remain
    satisfied.
    """
    _open = open_
    ratio = _open / _DEFAULT_OPEN if _DEFAULT_OPEN != 0 else Decimal("1")
    _high = high if high is not None else (_DEFAULT_HIGH * ratio).quantize(_DEFAULT_HIGH)
    _low = low if low is not None else (_DEFAULT_LOW * ratio).quantize(_DEFAULT_LOW)
    _close = close if close is not None else (_DEFAULT_CLOSE * ratio).quantize(_DEFAULT_CLOSE)
    return CandleModel(
        ts_utc=ts_utc or datetime(2026, 5, 1, 0, 0, tzinfo=timezone.utc),
        exchange=exchange,
        symbol=symbol or Symbol(base="BTC", quote="KRW"),
        timeframe=timeframe,
        open=_open,
        high=_high,
        low=_low,
        close=_close,
        volume=volume,
        value=value,
    )


def make_valid_orderbook(
    *,
    ts_utc: datetime | None = None,
    exchange: str = "bithumb",
    symbol: Symbol | None = None,
) -> OrderBookModel:
    return OrderBookModel(
        ts_utc=ts_utc or datetime(2026, 5, 1, 0, 0, tzinfo=timezone.utc),
        exchange=exchange,
        symbol=symbol or Symbol(base="BTC", quote="KRW"),
        bids=(
            OrderBookLevel(price=Decimal("100000000.00"), quantity=Decimal("0.5")),
            OrderBookLevel(price=Decimal("99950000.00"), quantity=Decimal("1.0")),
        ),
        asks=(
            OrderBookLevel(price=Decimal("100100000.00"), quantity=Decimal("0.4")),
            OrderBookLevel(price=Decimal("100200000.00"), quantity=Decimal("1.2")),
        ),
    )


def make_valid_order(
    *,
    order_id: str = "bt:run-1:1",
    symbol: Symbol | None = None,
    side: OrderSide = OrderSide.BUY,
    type: OrderType = OrderType.MARKET,
    status: OrderStatus = OrderStatus.NEW,
    quantity: Decimal = Decimal("0.001"),
    created_at: datetime | None = None,
    updated_at: datetime | None = None,
) -> Order:
    ts = created_at or datetime(2026, 5, 1, 0, 0, tzinfo=timezone.utc)
    return Order(
        order_id=OrderId(order_id),
        symbol=symbol or Symbol(base="BTC", quote="KRW"),
        side=side,
        type=type,
        status=status,
        quantity=quantity,
        filled_quantity=Decimal("0"),
        created_at=ts,
        updated_at=updated_at or ts,
    )


def make_invalid_naive_datetime_dict() -> dict[str, object]:
    """Boundary rejection: tzinfo=None datetime."""
    return {
        "ts_utc": datetime(2026, 5, 1, 0, 0),  # naive — boundary 가 reject
        "exchange": "bithumb",
        "symbol": Symbol(base="BTC", quote="KRW"),
        "timeframe": Timeframe.H1,
        "open": Decimal("100000000.00"),
        "high": Decimal("100500000.00"),
        "low": Decimal("99500000.00"),
        "close": Decimal("100200000.00"),
        "volume": Decimal("1.5"),
    }


def make_invalid_symbol_string() -> str:
    """Boundary rejection: missing separator."""
    return "btckrw"
