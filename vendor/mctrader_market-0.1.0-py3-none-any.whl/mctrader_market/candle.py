"""Candle Protocol (PEP 544) + CandleModel (Pydantic v2 boundary validation)."""

from __future__ import annotations

from datetime import datetime
from decimal import Decimal
from typing import Protocol, runtime_checkable

from pydantic import BaseModel, ConfigDict, model_validator

from mctrader_market.types import Decimal38_18, Symbol, Timeframe, UTCDateTime

# schema_version sentinel for ADR-009 16-column schema
_SCHEMA_VERSION = 1


@runtime_checkable
class CandleLike(Protocol):
    """Structural type for a single OHLCV bar (read-only Protocol).

    ADR-009 OHLCV v1 logical view. Decimal precision + timezone enforced at boundary
    via :class:`CandleModel`.
    """

    @property
    def ts_utc(self) -> datetime: ...
    @property
    def exchange(self) -> str: ...
    @property
    def symbol(self) -> Symbol: ...
    @property
    def timeframe(self) -> Timeframe: ...
    @property
    def open(self) -> Decimal: ...
    @property
    def high(self) -> Decimal: ...
    @property
    def low(self) -> Decimal: ...
    @property
    def close(self) -> Decimal: ...
    @property
    def volume(self) -> Decimal: ...
    @property
    def value(self) -> Decimal | None: ...


class CandleModel(BaseModel):
    """Pydantic v2 boundary validation for a single OHLCV bar.

    External boundary contract (adapter output / API I/O / fixture).
    Internal hot path (engine SMA loop) may use lighter types per ADR-010 7.10.
    """

    model_config = ConfigDict(strict=True, frozen=True, arbitrary_types_allowed=True)

    ts_utc: UTCDateTime
    exchange: str
    symbol: Symbol
    timeframe: Timeframe
    open: Decimal38_18
    high: Decimal38_18
    low: Decimal38_18
    close: Decimal38_18
    volume: Decimal38_18
    value: Decimal38_18 | None = None
    trade_count: int | None = None
    is_complete: bool = True
    source_ingested_at: UTCDateTime | None = None
    data_snapshot_id: str | None = None
    data_hash: str | None = None
    schema_version: int = _SCHEMA_VERSION
    quarantine_reason: str | None = None

    @model_validator(mode="after")
    def _validate_ohlcv_invariants(self) -> "CandleModel":
        """ADR-018 D3: cross-field OHLCV business invariants."""
        if self.high < self.open:
            raise ValueError(
                f"high ({self.high}) must be >= open ({self.open})"
            )
        if self.high < self.close:
            raise ValueError(
                f"high ({self.high}) must be >= close ({self.close})"
            )
        if self.high < self.low:
            raise ValueError(
                f"high ({self.high}) must be >= low ({self.low})"
            )
        if self.low > self.open:
            raise ValueError(
                f"low ({self.low}) must be <= open ({self.open})"
            )
        if self.low > self.close:
            raise ValueError(
                f"low ({self.low}) must be <= close ({self.close})"
            )
        if self.volume < 0:
            raise ValueError(
                f"volume ({self.volume}) must be >= 0"
            )
        return self
