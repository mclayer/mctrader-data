"""Candle Protocol (PEP 544) + CandleModel (Pydantic v2 boundary validation)."""

from __future__ import annotations

from datetime import datetime
from decimal import Decimal
from typing import Literal, Protocol, runtime_checkable

from pydantic import BaseModel, ConfigDict, model_validator

from mctrader_market.types import Decimal38_18, Symbol, Timeframe, UTCDateTime

# schema_version sentinel for ADR-009 16-column schema
_SCHEMA_VERSION = 1

# MCT-136 / ADR-009 §D8: provenance discriminator for OHLCV bar source.
CandleSource = Literal["legacy_candle", "transaction_derived"]
"""Where this candle was produced.

- ``legacy_candle``: emitted by exchange OHLCV REST/WS endpoints (e.g. Bithumb
  candlestick API). Direct provider output, no client-side aggregation.
- ``transaction_derived``: aggregated client-side from raw transaction (tick)
  stream by the Aggregation Core Lib (ADR-025). Surfaces ``value`` exactly and
  enables information bar refresh.
"""

# MCT-136: SemVer tag for the OHLCV contract revision carried with each row.
_DEFAULT_CONTRACT_METADATA_VERSION = "ohlcv.v1"


@runtime_checkable
class CandleLike(Protocol):
    """Structural type for a single OHLCV bar (read-only Protocol).

    ADR-009 OHLCV v1 logical view. Decimal precision + timezone enforced at boundary
    via :class:`CandleModel`.

    MCT-136 adds two provenance fields (``source`` / ``contract_metadata_version``)
    while preserving the baseline 10 OHLCV-shape attributes.

    Attributes are declared as class-level annotations (not ``@property``) so
    that :func:`typing.get_type_hints` can introspect the contract — see
    PEP 544 and the contract test in ``tests/protocols/test_candle_protocol.py``.
    """

    ts_utc: datetime
    exchange: str
    symbol: Symbol
    timeframe: Timeframe
    open: Decimal
    high: Decimal
    low: Decimal
    close: Decimal
    volume: Decimal
    value: Decimal | None
    source: CandleSource
    contract_metadata_version: str


class CandleModel(BaseModel):
    """Pydantic v2 boundary validation for a single OHLCV bar.

    External boundary contract (adapter output / API I/O / fixture).
    Internal hot path (engine SMA loop) may use lighter types per ADR-010 7.10.
    """

    model_config = ConfigDict(strict=True, frozen=True, arbitrary_types_allowed=True)

    ts_utc: UTCDateTime
    exchange: str
    symbol: Symbol
    timeframe: Timeframe
    open: Decimal38_18
    high: Decimal38_18
    low: Decimal38_18
    close: Decimal38_18
    volume: Decimal38_18
    value: Decimal38_18 | None = None
    trade_count: int | None = None
    is_complete: bool = True
    source_ingested_at: UTCDateTime | None = None
    data_snapshot_id: str | None = None
    data_hash: str | None = None
    schema_version: int = _SCHEMA_VERSION
    quarantine_reason: str | None = None
    # MCT-136 / ADR-009 §D8 — provenance discriminator. Default = ``legacy_candle``
    # so all existing call sites (engine / data / web) instantiate unchanged.
    source: CandleSource = "legacy_candle"
    # MCT-136 — SemVer tag for the OHLCV row contract revision. Information bar
    # rows (ADR-009 §D15) carry their own ``info_bar.v1`` tag on a different class.
    contract_metadata_version: str = _DEFAULT_CONTRACT_METADATA_VERSION

    @model_validator(mode="after")
    def _validate_ohlcv_invariants(self) -> CandleModel:
        """ADR-018 D3: cross-field OHLCV business invariants."""
        if self.high < self.open:
            raise ValueError(
                f"high ({self.high}) must be >= open ({self.open})"
            )
        if self.high < self.close:
            raise ValueError(
                f"high ({self.high}) must be >= close ({self.close})"
            )
        if self.high < self.low:
            raise ValueError(
                f"high ({self.high}) must be >= low ({self.low})"
            )
        if self.low > self.open:
            raise ValueError(
                f"low ({self.low}) must be <= open ({self.open})"
            )
        if self.low > self.close:
            raise ValueError(
                f"low ({self.low}) must be <= close ({self.close})"
            )
        if self.volume < 0:
            raise ValueError(
                f"volume ({self.volume}) must be >= 0"
            )
        return self
