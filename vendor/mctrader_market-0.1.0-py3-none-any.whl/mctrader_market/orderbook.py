"""OrderBook Protocol + OrderBookModel."""

from __future__ import annotations

from datetime import datetime
from decimal import Decimal
from enum import StrEnum
from typing import Protocol, runtime_checkable

from pydantic import BaseModel, ConfigDict

from mctrader_market.types import Decimal38_18, Symbol, UTCDateTime


class OrderBookSide(StrEnum):
    BID = "BID"
    ASK = "ASK"


@runtime_checkable
class OrderBookLike(Protocol):
    @property
    def ts_utc(self) -> datetime: ...
    @property
    def symbol(self) -> Symbol: ...
    @property
    def bids(self) -> list[tuple[Decimal, Decimal]]: ...
    @property
    def asks(self) -> list[tuple[Decimal, Decimal]]: ...


class OrderBookLevel(BaseModel):
    model_config = ConfigDict(strict=True, frozen=True)
    price: Decimal38_18
    quantity: Decimal38_18


class OrderBookModel(BaseModel):
    model_config = ConfigDict(strict=True, frozen=True, arbitrary_types_allowed=True)
    ts_utc: UTCDateTime
    exchange: str
    symbol: Symbol
    bids: tuple[OrderBookLevel, ...]
    asks: tuple[OrderBookLevel, ...]
