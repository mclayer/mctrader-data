"""OrderBook Protocol + OrderBookModel."""

from __future__ import annotations

from datetime import datetime
from enum import StrEnum
from typing import Protocol, runtime_checkable

from pydantic import BaseModel, ConfigDict

from mctrader_market.types import Decimal38_18, Symbol, UTCDateTime


class OrderBookSide(StrEnum):
    BID = "BID"
    ASK = "ASK"


class OrderBookLevel(BaseModel):
    model_config = ConfigDict(strict=True, frozen=True)
    price: Decimal38_18
    quantity: Decimal38_18


@runtime_checkable
class OrderBookLike(Protocol):
    """Structural type for an order book snapshot (read-only Protocol).

    ``bids`` / ``asks`` carry the same :class:`OrderBookLevel` tuple emitted by
    :class:`OrderBookModel` so adapter outputs satisfy the Protocol without an
    intermediate transform.
    """

    @property
    def ts_utc(self) -> datetime: ...
    @property
    def symbol(self) -> Symbol: ...
    @property
    def bids(self) -> tuple[OrderBookLevel, ...]: ...
    @property
    def asks(self) -> tuple[OrderBookLevel, ...]: ...


class OrderBookModel(BaseModel):
    model_config = ConfigDict(strict=True, frozen=True, arbitrary_types_allowed=True)
    ts_utc: UTCDateTime
    exchange: str
    symbol: Symbol
    bids: tuple[OrderBookLevel, ...]
    asks: tuple[OrderBookLevel, ...]
