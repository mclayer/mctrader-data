"""mctrader-market — Exchange-neutral market interface."""

from mctrader_market.candle import CandleLike, CandleModel
from mctrader_market.lifecycle import can_transition
from mctrader_market.order import Order, OrderSide, OrderStatus, OrderType
from mctrader_market.orderbook import OrderBookLike, OrderBookModel, OrderBookSide
from mctrader_market.providers import CandleProvider, OrderBookProvider
from mctrader_market.types import (
    Decimal38_18,
    OrderId,
    RunId,
    Symbol,
    Timeframe,
    TradeId,
    UTCDateTime,
)

__version__ = "0.1.0"

__all__ = [
    "CandleLike",
    "CandleModel",
    "CandleProvider",
    "Decimal38_18",
    "Order",
    "OrderBookLike",
    "OrderBookModel",
    "OrderBookProvider",
    "OrderBookSide",
    "OrderId",
    "OrderSide",
    "OrderStatus",
    "OrderType",
    "RunId",
    "Symbol",
    "Timeframe",
    "TradeId",
    "UTCDateTime",
    "__version__",
    "can_transition",
]
