"""Domain types — Symbol value object, Timeframe enum, Decimal/UTCDateTime annotations, ID NewTypes."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from decimal import ROUND_DOWN, Decimal, localcontext
from enum import StrEnum
from typing import Annotated, NewType

from pydantic import AfterValidator, BeforeValidator

OrderId = NewType("OrderId", str)
TradeId = NewType("TradeId", str)
RunId = NewType("RunId", str)


def _ensure_utc(value: datetime) -> datetime:
    """Validate timezone-aware UTC datetime (naive reject + non-UTC reject + canonicalize tzinfo)."""
    if value.tzinfo is None:
        raise ValueError("naive datetime not allowed (ADR-009 boundary requires UTC)")
    if value.utcoffset() != timedelta(0):
        raise ValueError(
            f"non-UTC datetime: tzinfo={value.tzinfo} (ADR-009 boundary requires UTC)"
        )
    return value.replace(tzinfo=timezone.utc)


UTCDateTime = Annotated[datetime, AfterValidator(_ensure_utc)]
"""Timezone-aware UTC datetime. Boundary validator rejects naive and non-UTC offsets."""


_QUANTIZE_18 = Decimal("1.000000000000000000")
_DECIMAL_38_PREC = 38
"""Local context precision matching Decimal38_18 type spec (38 total digits, 18 fraction).

Default Decimal context has prec=28 — fails quantize for values with integer part >= 10^10
(e.g., low-priced tokens like KRW-PEPE at 0.0065 KRW with quantity ~1e11 from orderbook).
Local context sized to the type spec (38) covers the full Decimal38_18 range.
"""


def _coerce_decimal_38_18(value: object) -> Decimal:
    if isinstance(value, float):
        raise ValueError("float input not allowed; use Decimal or str")
    if isinstance(value, Decimal):
        dec = value
    elif isinstance(value, (int, str)):
        dec = Decimal(value)
    else:
        raise TypeError(f"unsupported type for Decimal38_18: {type(value).__name__}")
    with localcontext() as ctx:
        ctx.prec = _DECIMAL_38_PREC
        result = dec.quantize(_QUANTIZE_18, rounding=ROUND_DOWN)
    if result.is_nan() or result.is_infinite():
        raise ValueError(f"Decimal38_18 does not allow NaN or Infinite values: {value!r}")
    sign, digits, _ = result.as_tuple()
    if len(digits) > _DECIMAL_38_PREC:
        raise ValueError(
            f"Decimal38_18 exceeds 38 total digits: {len(digits)} digits in {value!r}"
        )
    return result


Decimal38_18 = Annotated[Decimal, BeforeValidator(_coerce_decimal_38_18)]
"""Decimal with at most 18 decimal places (ADR-009 OHLCV canonical precision).

Auto-quantized down to 18 places at the boundary so internal computations may carry
extra precision without raising ``decimal_max_places``.
"""


@dataclass(frozen=True, slots=True)
class Symbol:
    """Exchange-neutral symbol value object.

    Canonical string form: ``"{quote}-{base}"`` (e.g., ``KRW-BTC``).
    """

    base: str
    quote: str

    def __post_init__(self) -> None:
        if not self.base:
            raise ValueError("Symbol.base must be non-empty")
        if not self.quote:
            raise ValueError("Symbol.quote must be non-empty")
        if self.base.strip() != self.base:
            raise ValueError(f"Symbol.base must not contain whitespace: {self.base!r}")
        if self.quote.strip() != self.quote:
            raise ValueError(f"Symbol.quote must not contain whitespace: {self.quote!r}")
        if self.base != self.base.upper():
            raise ValueError(f"Symbol.base must be uppercase: {self.base!r}")
        if self.quote != self.quote.upper():
            raise ValueError(f"Symbol.quote must be uppercase: {self.quote!r}")

    @classmethod
    def from_string(cls, value: str) -> Symbol:
        """Parse canonical ``"{quote}-{base}"`` form."""
        if "-" not in value:
            raise ValueError(f"invalid symbol (missing '-' separator): {value!r}")
        parts = value.split("-", 1)
        quote, base = parts[0], parts[1]
        if "-" in quote or "-" in base:
            raise ValueError(
                f"invalid symbol (extra '-' separator — multi-part not allowed): {value!r}"
            )
        return cls(base=base.upper(), quote=quote.upper())

    def __str__(self) -> str:
        return f"{self.quote}-{self.base}"


class Timeframe(StrEnum):
    """Closed Timeframe enum (ADR-009 partition path canonical form)."""

    M1 = "1m"
    M5 = "5m"
    M15 = "15m"
    H1 = "1h"
    H4 = "4h"
    D1 = "1d"

    @property
    def delta(self) -> timedelta:
        """Approximate timedelta — not calendar-aware (D1 = 24h, KST boundary handled in storage)."""
        mapping = {
            Timeframe.M1: timedelta(minutes=1),
            Timeframe.M5: timedelta(minutes=5),
            Timeframe.M15: timedelta(minutes=15),
            Timeframe.H1: timedelta(hours=1),
            Timeframe.H4: timedelta(hours=4),
            Timeframe.D1: timedelta(days=1),
        }
        return mapping[self]
