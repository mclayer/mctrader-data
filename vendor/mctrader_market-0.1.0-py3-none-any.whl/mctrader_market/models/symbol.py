from __future__ import annotations

from datetime import datetime
from decimal import Decimal

from sqlalchemy import CheckConstraint, Numeric, String, TIMESTAMP, UniqueConstraint, func
from sqlalchemy.orm import Mapped, mapped_column

from mctrader_market.models.base import Base


class Symbol(Base):
    __tablename__ = "symbols"
    __table_args__ = (
        UniqueConstraint("exchange", "symbol", name="uq_symbols_exchange_symbol"),
        CheckConstraint("symbol ~ '^[A-Z]+-[A-Z]+$'", name="ck_symbol_canonical_format"),
        {"schema": "market"},
    )

    id: Mapped[int] = mapped_column(primary_key=True)
    exchange: Mapped[str] = mapped_column(String(32))
    symbol: Mapped[str] = mapped_column(String(32))
    base_asset: Mapped[str] = mapped_column(String(16))
    quote_asset: Mapped[str] = mapped_column(String(16))
    status: Mapped[str] = mapped_column(String(16))
    score: Mapped[Decimal | None] = mapped_column(Numeric(6, 4))
    included_at: Mapped[datetime] = mapped_column(TIMESTAMP(timezone=True))
    excluded_at: Mapped[datetime | None] = mapped_column(TIMESTAMP(timezone=True))
    updated_at: Mapped[datetime] = mapped_column(
        TIMESTAMP(timezone=True),
        server_default=func.now(),
        onupdate=func.now(),
    )
