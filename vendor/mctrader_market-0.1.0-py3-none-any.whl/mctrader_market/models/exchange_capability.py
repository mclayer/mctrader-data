from __future__ import annotations

from datetime import datetime
from decimal import Decimal

from sqlalchemy import Numeric, String, TIMESTAMP, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column

from mctrader_market.models.base import Base


class ExchangeCapability(Base):
    __tablename__ = "exchange_capabilities"
    __table_args__ = (
        UniqueConstraint(
            "exchange", "symbol", name="uq_exchange_cap_exchange_symbol"
        ),
        {"schema": "market"},
    )

    id: Mapped[int] = mapped_column(primary_key=True)
    exchange: Mapped[str] = mapped_column(String(32))
    symbol: Mapped[str] = mapped_column(String(32))
    tick_size: Mapped[Decimal | None] = mapped_column(Numeric(38, 18))
    min_order_qty: Mapped[Decimal | None] = mapped_column(Numeric(38, 18))
    min_order_notional_krw: Mapped[Decimal | None] = mapped_column(Numeric(38, 18))
    fee_maker: Mapped[Decimal | None] = mapped_column(Numeric(10, 8))
    fee_taker: Mapped[Decimal | None] = mapped_column(Numeric(10, 8))
    fetched_at: Mapped[datetime] = mapped_column(TIMESTAMP(timezone=True))
