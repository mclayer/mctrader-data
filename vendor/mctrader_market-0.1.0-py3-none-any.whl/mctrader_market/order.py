"""Order snapshot + 8-state lifecycle enum (ADR-002)."""

from __future__ import annotations

from decimal import Decimal
from enum import StrEnum

from pydantic import BaseModel, ConfigDict, Field, model_validator

from mctrader_market.types import Decimal38_18, OrderId, Symbol, UTCDateTime


class OrderStatus(StrEnum):
    """8-state Order lifecycle (ADR-002)."""

    NEW = "NEW"
    ACCEPTED = "ACCEPTED"
    PARTIALLY_FILLED = "PARTIALLY_FILLED"
    FILLED = "FILLED"
    CANCEL_REQUESTED = "CANCEL_REQUESTED"
    CANCELED = "CANCELED"
    REJECTED = "REJECTED"
    EXPIRED = "EXPIRED"


class OrderSide(StrEnum):
    BUY = "BUY"
    SELL = "SELL"


class OrderType(StrEnum):
    MARKET = "MARKET"
    LIMIT = "LIMIT"


class Order(BaseModel):
    """Immutable Order snapshot (deterministic replay anchor).

    State changes generate new snapshots / OrderEvent stream — no mutation.
    """

    model_config = ConfigDict(strict=True, frozen=True, arbitrary_types_allowed=True)

    order_id: OrderId
    symbol: Symbol
    side: OrderSide
    type: OrderType
    status: OrderStatus
    price: Decimal38_18 | None = None
    quantity: Decimal38_18
    filled_quantity: Decimal38_18 = Field(default_factory=lambda: Decimal("0"))
    created_at: UTCDateTime
    updated_at: UTCDateTime

    @model_validator(mode="after")
    def _check_invariants(self) -> "Order":
        # Quantity must be positive
        if self.quantity <= 0:
            raise ValueError(f"quantity must be > 0, got {self.quantity!r}")

        # LIMIT orders require a price
        if self.type == OrderType.LIMIT and self.price is None:
            raise ValueError("price must be set for LIMIT orders")

        # filled_quantity cannot exceed quantity
        if self.filled_quantity > self.quantity:
            raise ValueError(
                f"filled_quantity ({self.filled_quantity!r}) exceeds quantity ({self.quantity!r})"
            )

        # updated_at must not precede created_at
        if self.updated_at < self.created_at:
            raise ValueError(
                f"updated_at ({self.updated_at!r}) must be >= created_at ({self.created_at!r})"
            )

        return self
