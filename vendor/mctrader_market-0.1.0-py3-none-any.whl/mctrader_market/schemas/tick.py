"""tick.v1.1 schema (ADR-009 §D10.8 — minor extension over tick.v1.0).

Schema delta vs v1.0:
- baseline 8 columns preserved (ts_utc, exchange, symbol, trade_id, price,
  quantity, side, is_taker).
- 3 new columns appended for ingestion provenance + integrity:
    * ``ingest_seq`` (uint64) — monotonic per-stream ingest counter.
    * ``payload_hash`` (str)  — content-addressable digest of the raw payload.
    * ``validation_status`` (str enum) — OK / GAP / MALFORMED / RECONNECT_BOUNDARY.

Backward compatibility (SemVer MINOR per ADR-008):
- v1.0 reader silently ignores the 3 new columns (additive).
- v1.1 reader accepts a v1.0 row by defaulting:
    * ``ingest_seq`` / ``payload_hash`` → ``None``
    * ``validation_status``             → ``"OK"``

Wire-format note: this module exposes the *logical* schema only. Physical
PyArrow Schema construction is the responsibility of the persistence layer
in mctrader-data (see ADR-009 §D10).
"""

from __future__ import annotations

from decimal import Decimal
from enum import StrEnum
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, field_validator

from mctrader_market.types import Decimal38_18, Symbol, UTCDateTime

TICK_V1_SCHEMA_VERSION = "tick.v1.1"
"""SemVer tag for the tick row schema (ADR-008 ADR-009 §D10.8)."""

TICK_V1_1_COLUMNS: tuple[str, ...] = (
    # baseline (v1.0)
    "ts_utc",
    "exchange",
    "symbol",
    "trade_id",
    "price",
    "quantity",
    "side",
    "is_taker",
    # extension (v1.1)
    "ingest_seq",
    "payload_hash",
    "validation_status",
)
"""Ordered column manifest — single source of truth for the 11-col layout."""


class ValidationStatus(StrEnum):
    """Per-row ingestion validation outcome (ADR-009 §D10.8)."""

    OK = "OK"
    GAP = "GAP"
    MALFORMED = "MALFORMED"
    RECONNECT_BOUNDARY = "RECONNECT_BOUNDARY"


class TickRowV1_1(BaseModel):
    """tick.v1.1 row — 8 baseline + 3 extension columns.

    External boundary contract (raw tick ingestion, Parquet I/O, WS payloads).
    """

    model_config = ConfigDict(strict=True, frozen=True, arbitrary_types_allowed=True)

    # baseline (v1.0)
    ts_utc: UTCDateTime
    exchange: str
    symbol: Symbol
    trade_id: str
    price: Decimal38_18
    quantity: Decimal38_18
    side: Literal["BUY", "SELL"]
    is_taker: bool
    # extension (v1.1) — optional for backward compat with v1.0 emitters.
    ingest_seq: int | None = None
    payload_hash: str | None = None
    validation_status: Literal["OK", "GAP", "MALFORMED", "RECONNECT_BOUNDARY"] = "OK"

    @field_validator("price")
    @classmethod
    def _price_must_be_positive(cls, value: Decimal) -> Decimal:
        if value <= 0:
            raise ValueError(f"price ({value}) must be > 0")
        return value

    @field_validator("quantity")
    @classmethod
    def _quantity_must_be_non_negative(cls, value: Decimal) -> Decimal:
        if value < 0:
            raise ValueError(f"quantity ({value}) must be >= 0")
        return value

    @field_validator("ingest_seq")
    @classmethod
    def _ingest_seq_uint64(cls, value: int | None) -> int | None:
        if value is None:
            return value
        if value < 0:
            raise ValueError(f"ingest_seq ({value}) must be >= 0 (uint64)")
        # uint64 upper bound — guard against signed overflow at adapter layer.
        if value >= 1 << 64:
            raise ValueError(f"ingest_seq ({value}) exceeds uint64 range")
        return value


def parse_tick_v1_row_as_v1_1(row: dict[str, Any]) -> TickRowV1_1:
    """Adapt a v1.0 *or* v1.1 row dict into a :class:`TickRowV1_1`.

    Missing v1.1 extension columns are defaulted per ADR-009 §D10.8:
        * ``ingest_seq``        → ``None``
        * ``payload_hash``      → ``None``
        * ``validation_status`` → ``"OK"``

    This is the canonical backward-compat entry point for adapters consuming
    historical (v1.0) Parquet files via the v1.1-aware reader.
    """
    payload = dict(row)
    payload.setdefault("ingest_seq", None)
    payload.setdefault("payload_hash", None)
    payload.setdefault("validation_status", "OK")
    return TickRowV1_1(**payload)
