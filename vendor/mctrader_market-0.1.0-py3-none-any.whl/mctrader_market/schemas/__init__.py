"""Wire schemas for inter-process / inter-repo contracts (MCT-136 / Epic MCT-112).

This sub-package hosts schema definitions intended for serialization /
persistence layers (Parquet / Postgres / WS payloads) — distinct from the
in-process Protocols in :mod:`mctrader_market.protocols`.
"""

from mctrader_market.schemas.tick import (
    TICK_V1_1_COLUMNS,
    TICK_V1_SCHEMA_VERSION,
    TickRowV1_1,
    ValidationStatus,
    parse_tick_v1_row_as_v1_1,
)

__all__ = [
    "TICK_V1_1_COLUMNS",
    "TICK_V1_SCHEMA_VERSION",
    "TickRowV1_1",
    "ValidationStatus",
    "parse_tick_v1_row_as_v1_1",
]
