"""Aggregation Core Lib — Layer 0 contract (ADR-025, MCT-182, ADR-031 §D1).

Layer 0 FOUNDATION — market = DAG 최하위, data 비의존. INV-2 보장.
Origin: data-package aggregation physically relocated here (byte-equivalence, INV-1).

Public API (Hot/Cold consumer import target):
    from mctrader_market.aggregation import (
        TimeBarAggregator,
        VolumeBarAggregator,
        TickBarAggregator,
        DollarBarAggregator,
        ContractMetadata,
        compute_contract_id,
        to_scaled,
        from_scaled,
    )
"""

from __future__ import annotations

from mctrader_market.aggregation.contract_metadata import (
    ContractMetadata,
    compute_contract_id,
)
from mctrader_market.aggregation.core import (
    DollarBarAggregator,
    TickBarAggregator,
    TimeBarAggregator,
    VolumeBarAggregator,
)
from mctrader_market.aggregation.scaled_int import from_scaled, to_scaled

__all__ = [
    "ContractMetadata",
    "DollarBarAggregator",
    "TickBarAggregator",
    "TimeBarAggregator",
    "VolumeBarAggregator",
    "compute_contract_id",
    "from_scaled",
    "to_scaled",
]
