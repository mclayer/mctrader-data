"""CandleProvider + OrderBookProvider Protocols (read-side market data)."""

from __future__ import annotations

from collections.abc import Iterable
from typing import Protocol, runtime_checkable

from mctrader_market.candle import CandleLike
from mctrader_market.orderbook import OrderBookLike
from mctrader_market.types import Symbol, Timeframe, UTCDateTime


@runtime_checkable
class CandleProvider(Protocol):
    """Exchange-neutral candle source.

    Half-open interval semantics: ``[start, end)``.
    """

    def get_candles(
        self,
        symbol: Symbol,
        timeframe: Timeframe,
        start: UTCDateTime,
        end: UTCDateTime,
    ) -> Iterable[CandleLike]: ...


@runtime_checkable
class OrderBookProvider(Protocol):
    """Exchange-neutral orderbook snapshot source."""

    def get_orderbook(self, symbol: Symbol) -> OrderBookLike: ...
