from __future__ import annotations

import os

from sqlalchemy import Engine, create_engine
from sqlalchemy.orm import Session, sessionmaker


def make_engine(url: str | None = None, schema: str = "market") -> Engine:
    resolved = url or os.environ["DATABASE_URL"]
    return create_engine(
        resolved,
        connect_args={"options": f"-csearch_path={schema},public"},
    )


def make_session_factory(engine: Engine | None = None) -> sessionmaker[Session]:
    return sessionmaker(bind=engine or make_engine())
