"""Domain protocols for non-OHLCV bar contracts (MCT-136 / Epic MCT-112).

This sub-package hosts read-only PEP 544 Protocols introduced after the
legacy ``mctrader_market.candle`` baseline (which stays at its existing
top-level module for backward compatibility). New protocols introduced in
Story-2 (Candle Protocol redefine + Information bar contract) and beyond
live here.
"""

from mctrader_market.protocols.information_bar import (
    InformationBar,
    InformationBarModel,
)

__all__ = ["InformationBar", "InformationBarModel"]
