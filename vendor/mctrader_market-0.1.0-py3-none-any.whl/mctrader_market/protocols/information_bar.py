"""Information bar Protocol (ADR-009 §D15) + InformationBarModel boundary.

Story scope (MCT-136 / Epic MCT-112 Story-2):
- ``InformationBar`` PEP 544 Protocol — runtime-checkable read-only view.
- ``InformationBarModel`` — Pydantic v2 boundary class enforcing Decimal /
  UTC / OHLCV invariants and ``bar_label`` prefix discriminator.

Discriminator (``bar_label`` prefix):
- ``time_<seconds>`` — fixed wall-clock interval bar (e.g. ``time_5m`` → 300s).
- ``vol_<threshold>`` — accumulated base volume bar.
- ``tick_<count>`` — fixed tick count bar.
- ``dollar_<value>`` — accumulated quote value bar.
"""

from __future__ import annotations

from datetime import datetime
from decimal import Decimal
from typing import Protocol, runtime_checkable

from pydantic import BaseModel, ConfigDict, field_validator, model_validator

from mctrader_market.types import Decimal38_18, Symbol, UTCDateTime

_INFORMATION_BAR_PREFIXES: tuple[str, ...] = ("time_", "vol_", "tick_", "dollar_")
"""Allowed ``bar_label`` prefixes per ADR-009 §D15."""

_DEFAULT_CONTRACT_METADATA_VERSION = "info_bar.v1"


@runtime_checkable
class InformationBar(Protocol):
    """Structural type for a single information bar (read-only Protocol).

    ADR-009 §D15 logical view. Carries OHLCV columns plus information-bar
    specific provenance (``bar_label`` / ``genesis_ts`` / ``threshold`` /
    ``ts_close`` / ``contract_metadata_version``). Decimal precision + UTC
    enforced at boundary via :class:`InformationBarModel`.

    Attributes declared as class-level annotations (not ``@property``) so that
    :func:`typing.get_type_hints` can introspect the contract.
    """

    bar_label: str
    genesis_ts: datetime
    ts_close: datetime
    threshold: Decimal
    contract_metadata_version: str
    exchange: str
    symbol: Symbol
    open: Decimal
    high: Decimal
    low: Decimal
    close: Decimal
    volume: Decimal
    value: Decimal | None


class InformationBarModel(BaseModel):
    """Pydantic v2 boundary validation for a single information bar.

    External boundary contract (Aggregation Core Lib emitter / API I/O /
    fixture). Internal hot path may use lighter intermediate buffers per
    ADR-010 7.10.
    """

    model_config = ConfigDict(strict=True, frozen=True, arbitrary_types_allowed=True)

    bar_label: str
    genesis_ts: UTCDateTime
    ts_close: UTCDateTime
    threshold: Decimal38_18
    contract_metadata_version: str = _DEFAULT_CONTRACT_METADATA_VERSION
    exchange: str
    symbol: Symbol
    open: Decimal38_18
    high: Decimal38_18
    low: Decimal38_18
    close: Decimal38_18
    volume: Decimal38_18
    value: Decimal38_18 | None = None

    @field_validator("bar_label")
    @classmethod
    def _validate_bar_label(cls, value: str) -> str:
        for prefix in _INFORMATION_BAR_PREFIXES:
            if value.startswith(prefix):
                suffix = value[len(prefix):]
                if not suffix:
                    raise ValueError(
                        f"bar_label must include a suffix after prefix {prefix!r}: "
                        f"got {value!r}"
                    )
                return value
        raise ValueError(
            f"bar_label must start with one of "
            f"{_INFORMATION_BAR_PREFIXES}: got {value!r}"
        )

    @model_validator(mode="after")
    def _validate_invariants(self) -> InformationBarModel:
        """ADR-009 §D15: threshold > 0, ts_close > genesis_ts, OHLCV invariants."""
        if self.threshold <= 0:
            raise ValueError(
                f"threshold ({self.threshold}) must be > 0 (ADR-009 §D15)"
            )
        if self.ts_close <= self.genesis_ts:
            raise ValueError(
                f"ts_close ({self.ts_close.isoformat()}) must be > "
                f"genesis_ts ({self.genesis_ts.isoformat()})"
            )
        # OHLCV invariants (mirror ADR-018 D3 for candle)
        if self.high < self.open:
            raise ValueError(
                f"high ({self.high}) must be >= open ({self.open})"
            )
        if self.high < self.close:
            raise ValueError(
                f"high ({self.high}) must be >= close ({self.close})"
            )
        if self.high < self.low:
            raise ValueError(
                f"high ({self.high}) must be >= low ({self.low})"
            )
        if self.low > self.open:
            raise ValueError(
                f"low ({self.low}) must be <= open ({self.open})"
            )
        if self.low > self.close:
            raise ValueError(
                f"low ({self.low}) must be <= close ({self.close})"
            )
        if self.volume < 0:
            raise ValueError(
                f"volume ({self.volume}) must be >= 0"
            )
        return self
