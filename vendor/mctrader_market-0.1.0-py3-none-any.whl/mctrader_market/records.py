"""Pure dataclass records (Layer 0 contract, INV-3 — pyarrow 비결합).

Origin: TickRecord/OrderbookEventRecord dataclass extracted from data-package (MCT-182, ADR-031 §D1).

stdlib only — pyarrow import 금지 (INV-3). field 순서/이름/default/__post_init__ message =
data 원본 byte-for-byte 보존 (pyarrow schema 가 field 순서 의존 — 순서 변경 시 직렬화 깨짐, INV-6).

pyarrow writer (TickWriter / OrderbookWriter) 는 mctrader-data 잔류 (INV-6).
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from decimal import Decimal


@dataclass
class TickRecord:
    ts_utc: datetime
    received_at: datetime
    exchange: str
    symbol: str
    price: Decimal
    quantity: Decimal
    side: str
    raw_json: str | None = None

    def __post_init__(self) -> None:
        if isinstance(self.price, float):
            raise TypeError("float not allowed for price; use Decimal or str")
        if isinstance(self.quantity, float):
            raise TypeError("float not allowed for quantity; use Decimal or str")


@dataclass
class OrderbookEventRecord:
    ts_utc: datetime
    received_at: datetime
    exchange: str
    symbol: str
    event_type: str  # "snapshot" or "delta"
    side: str  # "bid" or "ask"
    level: int  # 0-N for snapshot, -1 for delta
    price: Decimal
    quantity: Decimal
    raw_json: str | None = None

    def __post_init__(self) -> None:
        if isinstance(self.price, float):
            raise TypeError("float not allowed for price; use Decimal or str")
        if isinstance(self.quantity, float):
            raise TypeError("float not allowed for quantity; use Decimal or str")


__all__ = ["OrderbookEventRecord", "TickRecord"]
